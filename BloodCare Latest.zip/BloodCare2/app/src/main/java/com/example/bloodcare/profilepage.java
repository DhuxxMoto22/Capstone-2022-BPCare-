package com.example.bloodcare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class profilepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilepage);
    }
}